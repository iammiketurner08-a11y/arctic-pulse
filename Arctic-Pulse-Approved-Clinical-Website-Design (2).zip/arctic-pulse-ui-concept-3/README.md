# Arctic Pulse Website UI — Concept 3

A distinct modern editorial homepage direction for **Arctic Pulse Human Performance & Wellness Ltd.**, created from the original website brief.

## Visual direction

- Deep aubergine, muted berry, sage, warm oat, and porcelain palette
- Oversized editorial hero with an overlapping stock-image composition
- Contemporary bento service cards instead of horizontal rows or standard cards
- Circular practitioner portrait and pill-style credential system
- Rounded direct-billing dashboard and insurer matrix
- Immersive Arctic mobile-care panel
- Layered First Aid training imagery and compact course modules
- Modern impact, review, FAQ, booking, and detailed footer treatments

## Preview

Open `index.html` in a modern browser. All photography is stored locally in `assets/`, so the visual design works without an internet connection.

The prototype includes desktop, tablet, and mobile layouts; accessible navigation; expandable FAQs; a booking-request modal; and newsletter interaction.

## Before development launch

- Replace the illustrative practitioner portrait with an approved photograph of Samuel Cabrera.
- Replace sample testimonials with verified, client-approved reviews.
- Connect booking, forms, gift certificates, course registration, and newsletter actions to production systems.
- Confirm service hours, pricing, service radius, social profiles, insurer participation, and policy wording.

## Stock photography

- Massage treatment: [Unsplash photo by Jakub Klucký](https://unsplash.com/photos/massage-therapist-giving-a-back-massage-7yeqemd-p90)
- Assisted stretching: [Unsplash assisted-stretching collection](https://unsplash.com/s/photos/assisted-stretching)
- Arctic landscape: [Unsplash Arctic-landscape collection](https://unsplash.com/s/photos/arctic-landscape)
- Illustrative clinician portrait: [Unsplash photo by David Akinwale](https://unsplash.com/photos/a-surgeon-in-blue-scrubs-stands-in-an-operating-room-mOSuHTOqZF8)
- First Aid and CPR workshop: [Pexels photo by Tahir Xəlfəquliyev](https://www.pexels.com/photo/women-practicing-cpr-on-mannequins-in-workshop-33317473/)
